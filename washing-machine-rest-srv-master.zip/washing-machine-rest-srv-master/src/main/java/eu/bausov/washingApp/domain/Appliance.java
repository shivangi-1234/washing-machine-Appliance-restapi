package eu.bausov.washing_machine_rest_srv.domain;

public interface Appliance {
    String getModel();
    String getSerial();
}
