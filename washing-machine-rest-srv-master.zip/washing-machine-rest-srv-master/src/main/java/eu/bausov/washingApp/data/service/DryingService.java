package eu.bausov.washing_machine_rest_srv.data.service;

import eu.bausov.washing_machine_rest_srv.domain.program.process.Drying;

/**
 * for saving the drying process.
 */
public interface DryingService {
    Drying save(Drying drying);
}
