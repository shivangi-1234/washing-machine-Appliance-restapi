package eu.bausov.washing_machine_rest_srv.data.repository;

import eu.bausov.washing_machine_rest_srv.domain.program.process.Drying;
import org.springframework.data.repository.CrudRepository;

/**
 * for the drying process.
 */
public interface DryingRepository extends CrudRepository<Drying, Long> {
    Drying save(Drying process);
}
