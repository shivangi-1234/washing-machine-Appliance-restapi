package eu.bausov.washing_machine_rest_srv.util;

/**
 * This class defines States of the process.
 */
public enum  States {
    WAITING, RUNNING, FINISHED, STOPPED ;
}
