package eu.bausov.washing_machine_rest_srv.domain;

import eu.bausov.washing_machine_rest_srv.domain.program.Program;

import java.util.List;

public interface Programmable {
    List<Program> getPrograms();
}
