package eu.bausov.washing_machine_rest_srv.data.service;

import eu.bausov.washing_machine_rest_srv.domain.program.Program;

/**
 * for saving the program.
 */
public interface ProgramService {
    Program save(Program program);
}
